==================================================================
  REALISTIC GENETICS - a mod for The Sims 4   (BETA v2.9.62)
==================================================================

Makes babies actually inherit their looks from their real family.
Instead of the game's random roll, your Sims pass down hair color,
eye color, skin tone and facial features (nose, eyes, mouth, jaw,
cheeks, head shape) to their children.

How each one is inherited:
- Hair and eye color use real dominant and recessive genes, so a
  color can hide for a generation and reappear later.
- Skin tone blends the parents' tones (with some pull from further
  up the family), so kids land in a natural range for their family.
- Facial features are pulled from across the family, so a child
  might get their mom's eyes, their dad's mouth and a grandparent's
  nose.

Nothing appears out of nowhere. If a trait shows up, it traces back
to the family.

------------------------------------------------------------------
  WHAT'S CHANGED IN THIS UPDATE (2.9.62)
------------------------------------------------------------------
Faces were coming out same-y no matter who was in the family.
That's what this update fixes.

- Kids actually look like the relative they got each feature from.
  If a child gets her grandma's nose, it's grandma's nose - not a
  blend of five different people.

- Re-rolling a face works properly now. It used to build on top of
  the last roll, so after a few goes the face barely changed. You
  get a clean result every time.

- Noses, lips and jaws come out right. Bits of the fine detail were
  being taken from the wrong relative, which is what made everyone
  drift toward the same face.

------------------------------------------------------------------
  IMPORTANT IF YOU USED AN EARLIER BETA
------------------------------------------------------------------
Before installing, delete this folder:

    Mods/mod_data/RealisticGenetics

Earlier betas saved their own copies of your Sims' faces, and those
old copies can override the new results - a Sim keeps snapping back
to an odd face no matter what you do. Deleting the folder clears
them out.

It is safe. Your Sims keep the faces they already have - that lives
in your save, not in this folder. The mod just forgets its own
saved copies and starts fresh. You will want to re-roll a Sim to
give them the improved genetics.

If you are installing for the first time, ignore this - there is
nothing to delete.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.46)
------------------------------------------------------------------
Hair:

- Sims keep their own hairstyle. When a Sim inherits a family hair
  color, only the color changes now - they keep the exact cut they
  were wearing, in the right style for their age and gender.

- Much better hair color matching. Hair, eyebrow and facial hair
  colors are now read from the game's own color data instead of
  being guessed, which covers thousands more hairstyles and shades
  like salt-and-pepper and the warmer browns and blondes.

- Gray hair from aging is no longer inherited. An older Sim's gray
  is no longer mistaken for their family's natural hair color and
  passed down to grandchildren - it now reads their eyebrows to
  find the color they had before they went gray.

Faces:

- Better cross-gender feature matching. A child can now inherit
  cheeks, chin, brow and jaw from a relative of the opposite
  gender, which previously wasn't possible for those features.

Compatibility:

- Fixed births failing when MC Command Center is installed. The
  mother would reset, no baby would appear, and after reloading a
  child showed up with the name you picked but wasn't linked to
  its parents and looked nothing like the family. If that happened
  to you, this fixes the cause.

- Occult eye colors (vampire, alien, mermaid, fairy and so on) are
  now identified exactly rather than guessed, so they stay out of
  normal family inheritance.

Troubleshooting:

- New command: rg.whyface [name] explains, step by step, why a
  Sim's face did or didn't change. Handy if you ever need to
  report a problem.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.30)
------------------------------------------------------------------
Performance and inheritance fixes from beta feedback:

- Much faster loading. Loading a save no longer crawls. The mod
  used to touch every Sim in your whole save on load; now it only
  works on the Sims it actually has genetics for.

- No more save or Create-a-Sim freeze. Saving, entering CAS and
  travelling are quick again. The mod was re-writing all of its
  data every single time the game saved (which happens a lot);
  now it only writes when something actually changed. Nothing is
  lost, it just stops doing pointless work.

- Same-sex and gallery-parent births inherit properly. Babies from
  two same-gender parents, MCCC risky woohoo, or a gallery parent
  now pull genetics from both real parents instead of coming out
  with no family resemblance.

- "View inheritance" works for every Sim, including twins. Each
  baby now remembers its own breakdown, so siblings don't overwrite
  each other and an aged-up Sim still shows who they inherited from.

- Correct pronouns in the report (reads the Sim's actual gender
  instead of always saying "she").

Earlier baby and toddler fixes (still included):

- Babies no longer get grown-up hairstyles. Newborns now get an
  age-appropriate style in their inherited color instead of an
  adult 'do stuck on a baby head.

- Hospital births work. Having a baby at the hospital runs genetics
  and shows the report, same as a home birth.

- Twins and triplets are each handled properly. Every baby rolls
  its own genetics (so they don't come out identical), and you get
  a separate genetics report for EACH baby, one after another,
  instead of just one of them. This works at home AND at the
  hospital.

- Babies don't look "off" anymore. Newborns keep the game's normal
  baby face and grow into their inherited features as they age up.
  (The detailed face can't sit on a baby's head, which is a game
  limit, so it applies by the teen stage.)

- Inherited looks stick when Sims grow up. Aging up keeps the face
  and colors the family passed down.

- Edits in Create-a-Sim stick. If you tweak a Sim in CAS, your
  changes are kept and become their saved look, instead of being
  reverted the next time you load.

------------------------------------------------------------------
  WHAT YOU NEED
------------------------------------------------------------------
- The Sims 4 (any recent version).
- "Script mods" turned on (a one-time setting, see step 3 below).

------------------------------------------------------------------
  HOW TO INSTALL  (about 1 minute)
------------------------------------------------------------------
1. Unzip this download.

2. Drag  RealisticGenetics.ts4script  into your Mods folder:
     Documents > Electronic Arts > The Sims 4 > Mods
   (Just drop the file straight in. Do NOT put it inside extra
    sub-folders more than one level deep.)

3. Turn on script mods (one time only):
     Start the game > Options > Game Options > Other
     - Check "Enable Custom Content and Mods"
     - Check "Script Mods Allowed"
     Click Apply, then RESTART the game when it asks.

4. Check it loaded:
     Open the cheat console:  Ctrl + Shift + C   (Cmd + Shift + C on Mac)
     Type:  rg.ping   and press Enter.
     You should see:  "RealisticGenetics mod is loaded! Version: 2.9.46"
     (If nothing happens, script mods aren't on. Redo step 3.)

------------------------------------------------------------------
  HOW TO USE IT
------------------------------------------------------------------
Most of the time you do NOTHING. Genetics apply automatically when
a Sim is born, and a pop-up shows who they inherited from. For twins
or triplets you get one report per baby, in turn.

To open the menu for any Sim:
     Select the Sim, open the console (Ctrl+Shift+C),
     type:  realisticgenetics   and press Enter.
   You'll get a menu with the Sim's photo and these options:
     - Recalculate genetics   (re-roll their looks from family)
     - View inheritance       (see who they got each feature from)
     - Save genetics          (lock in the current look)
     - Refresh look           (fix hair/face that renders oddly)

Handy console commands (optional):
     rg.ping            confirm the mod is loaded and its version
     realisticgenetics  open the menu for the selected Sim
     rg.fixlook         snap a Sim's hair/face if it looks wrong
     rg.syncsim <Name>  re-apply a Sim's saved genetics (for example
                        after editing them in Create-a-Sim)
     rg.twins <mode>    how multiples inherit: random (default),
                        identical, or fraternal
     rg.help            list all the commands
     rg.diagnose        health check (use this for bug reports)

------------------------------------------------------------------
  IF SOMETHING LOOKS OFF
------------------------------------------------------------------
- Hair or face looks wrong on a Sim?  Select them and run
  rg.fixlook  in the console. It snaps the look into place.
- Aged a Sim up inside Create-a-Sim and the inherited face didn't
  apply?  Run  rg.syncsim <FirstName>  after you leave CAS. (Aging
  up with a birthday cake or the sims.age_up cheat applies it
  automatically; only the CAS age-up button needs the nudge.)
- This is a BETA, so bugs are expected. To report one, please send:
    1) What you did and what went wrong (a screenshot helps a lot).
    2) The file:  Documents > Electronic Arts > The Sims 4 >
                  Mods > mod_data > RealisticGenetics > birth_log.txt
    3) The output of  rg.diagnose  (run it in the console).

------------------------------------------------------------------
  UNINSTALL  (100% safe)
------------------------------------------------------------------
Just delete RealisticGenetics.ts4script from your Mods folder.
Your Sims keep the faces they already have and your saves are fine.
Only future automatic inheritance stops.

------------------------------------------------------------------
Thanks for beta testing!  Made with Realistic Genetics.
==================================================================
