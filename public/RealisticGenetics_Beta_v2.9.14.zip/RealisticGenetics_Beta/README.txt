==================================================================
  REALISTIC GENETICS  —  a mod for The Sims 4   (BETA v2.9.14)
==================================================================

Makes babies actually inherit their looks from their real family.
Instead of the game's random roll, your Sims pass down hair color,
eye color, skin tone, and facial features (nose, eyes, mouth, jaw,
cheeks, head shape) to their children — with real dominant/recessive
genetics, so traits can even skip a generation and reappear.

New in 2.9.14: Sims now keep their inherited face when they age
up (toddler -> child -> teen -> adult), instead of needing a manual
fix in Create-a-Sim.

------------------------------------------------------------------
  WHAT YOU NEED
------------------------------------------------------------------
- The Sims 4 (any recent version).
- "Script mods" turned on (one-time setting — step 3 below).

------------------------------------------------------------------
  HOW TO INSTALL  (about 1 minute)
------------------------------------------------------------------
1. Unzip this download.

2. Drag  RealisticGenetics.ts4script  into your Mods folder:
     Documents > Electronic Arts > The Sims 4 > Mods
   (Just drop the file straight in. Do NOT put it inside extra
    sub-folders more than one level deep.)

3. Turn on script mods (one time only):
     Start the game > Options > Game Options > Other
     - Check "Enable Custom Content and Mods"
     - Check "Script Mods Allowed"
     Click Apply, then RESTART the game when it asks.

4. Check it loaded:
     Open the cheat console:  Ctrl + Shift + C   (Cmd + Shift + C on Mac)
     Type:  rg.ping   and press Enter.
     You should see:  "RealisticGenetics mod is loaded! Version: 2.9.14"
     (If nothing happens, script mods aren't on — redo step 3.)

------------------------------------------------------------------
  HOW TO USE IT
------------------------------------------------------------------
Most of the time you do NOTHING — genetics apply automatically
when a Sim is born, and a pop-up shows who they inherited from.

To open the menu for any Sim:
     Click/select the Sim, open the console (Ctrl+Shift+C),
     type:  realisticgenetics   and press Enter.
   You'll get a menu with the Sim's photo and these options:
     - Recalculate genetics   (re-roll their looks from family)
     - View inheritance        (see who they got each feature from)
     - Save genetics           (lock in the current look)
     - Refresh look            (fix hair/face that renders oddly)

Handy console commands (optional):
     rg.ping            confirm the mod is loaded + version
     realisticgenetics  open the menu for the selected Sim
     rg.fixlook         snap a Sim's hair/face if it looks wrong
     rg.help            show the main commands
     rg.diagnose        health check (use this for bug reports)

------------------------------------------------------------------
  IF SOMETHING LOOKS OFF
------------------------------------------------------------------
- Hair or face looks weird on a Sim?  Select them and run
  rg.fixlook  in the console — it snaps the look into place.
- This is a BETA, so bugs are expected. To report one, please send:
    1) What you did and what went wrong (a screenshot helps a lot).
    2) The file:  Documents > Electronic Arts > The Sims 4 >
                  Mods > mod_data > RealisticGenetics > birth_log.txt
    3) The output of  rg.diagnose  (run it in the console).

------------------------------------------------------------------
  UNINSTALL  (100% safe)
------------------------------------------------------------------
Just delete RealisticGenetics.ts4script from your Mods folder.
Your Sims keep the faces they already have and your saves are fine —
only future automatic inheritance stops.

------------------------------------------------------------------
Thanks for beta testing!  Made with Realistic Genetics.
==================================================================
