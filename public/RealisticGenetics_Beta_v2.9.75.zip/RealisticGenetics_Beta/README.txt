==================================================================
  REALISTIC GENETICS - a mod for The Sims 4   (BETA v2.9.75)
==================================================================

Makes babies actually inherit their looks from their real family.
Instead of the game's random roll, your Sims pass down hair color,
eye color, skin tone and facial features (nose, eyes, mouth, jaw,
cheeks, head shape) to their children.

How each one is inherited:
- Hair and eye color use real dominant and recessive genes, so a
  color can hide for a generation and reappear later.
- Skin tone blends the parents' tones (with some pull from further
  up the family), so kids land in a natural range for their family.
- Facial features are pulled from across the family, so a child
  might get their mom's eyes, their dad's mouth and a grandparent's
  nose.

Nothing appears out of nowhere. If a trait shows up, it traces back
to the family.

------------------------------------------------------------------
  WHAT'S CHANGED IN THIS UPDATE (2.9.75)
------------------------------------------------------------------
One fix: the face a baby inherits now actually shows up when
they grow to teen.

- The inherited face arrives at the teen birthday. Faces only
  apply from teen upwards, so a Sim born in your game waits
  until then to get theirs. That step was failing quietly, and
  they grew up wearing the game's own face instead - still
  family-looking, but not the face the mod rolled. "View
  inheritance" showed the right thing the whole time, because
  the genetics were never wrong; only the step that puts them
  on the Sim was.

  Sims who already grew up this way keep the face they have.
  Run rg.syncsim on them once to put the right one back.

  PLEASE NOTE: after a baby is born and you've saved their genetics
  from the card, SAVE YOUR GAME STRAIGHT AWAY so the game locks it
  in.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.74)
------------------------------------------------------------------
Two fixes: births that ended with no baby, and the re-roll button
on the newborn card.

- Births that ended with no baby. Some births finished with an
  empty bassinet - no baby, the mother resetting, and the child
  missing from the family tree. This could happen on its own or
  alongside MC Command Center. Fixed.

- Re-roll on the newborn card actually re-rolls now. Pressing the
  dice gave you the same relatives every time. It now rolls a fresh
  combination each press. On a baby you'll see the family names on
  the card change rather than the face - faces still arrive at the
  teen birthday, as before.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.72)
------------------------------------------------------------------
The newborn card now tells you who each feature came from, and the
mod plays better alongside MC Command Center.

- The card you get when a baby is born now lists which relative each
  feature came from. It used to say no features against everyone,
  including the parents, and only read properly once the Sim grew
  up - or it showed the previous Sim's relatives instead, which is
  why it seemed to work sometimes and not others. The inheritance
  itself was always correct; only the card was wrong. The baby's
  face still changes at the teen birthday, as before, so the card
  is a preview of what is coming.

- Better behaved with MC Command Center. Realistic Genetics and MCCC
  both adjust the same part of the game when a baby is created.
  Depending on which of them the game loaded first, that could fail -
  and when it did, the baby was never finished being made: no baby,
  the mother acting strangely, and the child missing from the family
  tree. It now works whichever order they load in.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.68)
------------------------------------------------------------------
Faces stop resetting when you come out of CAS, and edits you make
in there stay put.

- Faces no longer reset after a trip through CAS. Every time a Sim
  went into CAS and came out, the game was deleting the jaw shape
  the mod had given them and swapping out the cheek shape. Losing
  those two was enough to visibly reset the face, and it happened
  even if you went in and changed nothing. Jaw and cheek shapes are
  left to the game now, so nothing gets thrown away. Both still
  inherit through their sliders, so a Sim still gets their family's
  jawline and cheekbones.

- Edits you make in CAS stick. Go in, change whatever you like,
  save, and it stays. Earlier betas would put the mod's rolled face
  back over the top of your changes.

- Bodies are not exaggerated anymore. Body sliders were piling up
  from every relative instead of coming from one, so Sims came out
  with the bust, waist and hips of six different people stacked
  together. A Sim now carries about one body's worth.

- The mod keeps its data in one folder. It used to write to a new
  folder whenever the game reported a different save slot, and old
  copies in the other folders could override the new results. Any
  folders you already have get merged automatically on first load,
  and nothing is deleted.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.64)
------------------------------------------------------------------
More of a Sim's face now comes from the relative it is supposed to
come from.

- Chins and cheeks pass down between sons and daughters now. A
  daughter could inherit her grandfather's chin and the game would
  quietly throw it away, because the mod had no way to translate a
  male chin into its female equivalent. It does now, for chins, and
  for cheeks as a start.

- Fixed sliders that were filed under the wrong part of the face.
  Seven of them. One example: a slider that shapes the jaw was
  filed under the nose, so part of a Sim's jaw came from whoever
  gave them their nose instead. Brow detail was not recognised at
  all and drifted to a random relative.

- Stopped a Sim snapping back to the same odd face however many
  times you re-rolled. The mod was saving a face the game had
  rebuilt and then restoring it forever after.

------------------------------------------------------------------
  IMPORTANT IF YOU USED AN EARLIER BETA
------------------------------------------------------------------
Run this once in the cheat console after updating:

    rg.clearmemory

Or pick "Clear saved faces" from the Realistic Genetics menu.

Earlier betas saved their own copies of your Sims' faces, and an old
copy can override the new results - a Sim keeps snapping back to an
odd face no matter what you do. This clears them out, across every
save folder, and backs them up first. This version also merges those
folders into one by itself when you first load a save.

It is safe. Your Sims keep the faces they already have - that lives
in your save, not in the mod's folder. Re-roll a Sim to give them
the improved genetics.

If you are installing for the first time, you can ignore this.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.46)
------------------------------------------------------------------
Hair:

- Sims keep their own hairstyle. When a Sim inherits a family hair
  color, only the color changes now - they keep the exact cut they
  were wearing, in the right style for their age and gender.

- Much better hair color matching. Hair, eyebrow and facial hair
  colors are now read from the game's own color data instead of
  being guessed, which covers thousands more hairstyles and shades
  like salt-and-pepper and the warmer browns and blondes.

- Gray hair from aging is no longer inherited. An older Sim's gray
  is no longer mistaken for their family's natural hair color and
  passed down to grandchildren - it now reads their eyebrows to
  find the color they had before they went gray.

Faces:

- Better cross-gender feature matching. A child can now inherit
  cheeks, chin, brow and jaw from a relative of the opposite
  gender, which previously wasn't possible for those features.

Compatibility:

- Fixed births failing when MC Command Center is installed. The
  mother would reset, no baby would appear, and after reloading a
  child showed up with the name you picked but wasn't linked to
  its parents and looked nothing like the family. If that happened
  to you, this fixes the cause.

- Occult eye colors (vampire, alien, mermaid, fairy and so on) are
  now identified exactly rather than guessed, so they stay out of
  normal family inheritance.

Troubleshooting:

- New command: rg.whyface [name] explains, step by step, why a
  Sim's face did or didn't change. Handy if you ever need to
  report a problem.

------------------------------------------------------------------
  EARLIER IN THIS BETA (2.9.30)
------------------------------------------------------------------
Performance and inheritance fixes from beta feedback:

- Much faster loading. Loading a save no longer crawls. The mod
  used to touch every Sim in your whole save on load; now it only
  works on the Sims it actually has genetics for.

- No more save or Create-a-Sim freeze. Saving, entering CAS and
  travelling are quick again. The mod was re-writing all of its
  data every single time the game saved (which happens a lot);
  now it only writes when something actually changed. Nothing is
  lost, it just stops doing pointless work.

- Same-sex and gallery-parent births inherit properly. Babies from
  two same-gender parents, MCCC risky woohoo, or a gallery parent
  now pull genetics from both real parents instead of coming out
  with no family resemblance.

- "View inheritance" works for every Sim, including twins. Each
  baby now remembers its own breakdown, so siblings don't overwrite
  each other and an aged-up Sim still shows who they inherited from.

- Correct pronouns in the report (reads the Sim's actual gender
  instead of always saying "she").

Earlier baby and toddler fixes (still included):

- Babies no longer get grown-up hairstyles. Newborns now get an
  age-appropriate style in their inherited color instead of an
  adult 'do stuck on a baby head.

- Hospital births work. Having a baby at the hospital runs genetics
  and shows the report, same as a home birth.

- Twins and triplets are each handled properly. Every baby rolls
  its own genetics (so they don't come out identical), and you get
  a separate genetics report for EACH baby, one after another,
  instead of just one of them. This works at home AND at the
  hospital.

- Babies don't look "off" anymore. Newborns keep the game's normal
  baby face and grow into their inherited features as they age up.
  (The detailed face can't sit on a baby's head, which is a game
  limit, so it applies by the teen stage.)

- Inherited looks stick when Sims grow up. Aging up keeps the face
  and colors the family passed down.

- Edits in Create-a-Sim stick. If you tweak a Sim in CAS, your
  changes are kept and become their saved look, instead of being
  reverted the next time you load.

------------------------------------------------------------------
  WHAT YOU NEED
------------------------------------------------------------------
- The Sims 4 (any recent version).
- "Script mods" turned on (a one-time setting, see step 3 below).

------------------------------------------------------------------
  HOW TO INSTALL  (about 1 minute)
------------------------------------------------------------------
1. Unzip this download.

2. Drag  RealisticGenetics.ts4script  into your Mods folder:
     Documents > Electronic Arts > The Sims 4 > Mods
   (Just drop the file straight in. Do NOT put it inside extra
    sub-folders more than one level deep.)

3. Turn on script mods (one time only):
     Start the game > Options > Game Options > Other
     - Check "Enable Custom Content and Mods"
     - Check "Script Mods Allowed"
     Click Apply, then RESTART the game when it asks.

4. Check it loaded:
     Open the cheat console:  Ctrl + Shift + C   (Cmd + Shift + C on Mac)
     Type:  rg.ping   and press Enter.
     You should see:  "RealisticGenetics mod is loaded! Version: 2.9.46"
     (If nothing happens, script mods aren't on. Redo step 3.)

------------------------------------------------------------------
  HOW TO USE IT
------------------------------------------------------------------
Most of the time you do NOTHING. Genetics apply automatically when
a Sim is born, and a pop-up shows who they inherited from. For twins
or triplets you get one report per baby, in turn.

To open the menu for any Sim:
     Select the Sim, open the console (Ctrl+Shift+C),
     type:  realisticgenetics   and press Enter.
   You'll get a menu with the Sim's photo and these options:
     - Recalculate genetics   (re-roll their looks from family)
     - View inheritance       (see who they got each feature from)
     - Save genetics          (lock in the current look)
     - Refresh look           (fix hair/face that renders oddly)

Handy console commands (optional):
     rg.ping            confirm the mod is loaded and its version
     realisticgenetics  open the menu for the selected Sim
     rg.fixlook         snap a Sim's hair/face if it looks wrong
     rg.syncsim <Name>  re-apply a Sim's saved genetics (for example
                        after editing them in Create-a-Sim)
     rg.twins <mode>    how multiples inherit: random (default),
                        identical, or fraternal
     rg.help            list all the commands
     rg.diagnose        health check (use this for bug reports)

------------------------------------------------------------------
  IF SOMETHING LOOKS OFF
------------------------------------------------------------------
- Hair or face looks wrong on a Sim?  Select them and run
  rg.fixlook  in the console. It snaps the look into place.
- Aged a Sim up inside Create-a-Sim and the inherited face didn't
  apply?  Run  rg.syncsim <FirstName>  after you leave CAS. (Aging
  up with a birthday cake or the sims.age_up cheat applies it
  automatically; only the CAS age-up button needs the nudge.)
- This is a BETA, so bugs are expected. To report one, please send:
    1) What you did and what went wrong (a screenshot helps a lot).
    2) The file:  Documents > Electronic Arts > The Sims 4 >
                  Mods > mod_data > RealisticGenetics > birth_log.txt
    3) The output of  rg.diagnose  (run it in the console).

------------------------------------------------------------------
  UNINSTALL  (100% safe)
------------------------------------------------------------------
Just delete RealisticGenetics.ts4script from your Mods folder.
Your Sims keep the faces they already have and your saves are fine.
Only future automatic inheritance stops.

------------------------------------------------------------------
Thanks for beta testing!  Made with Realistic Genetics.
==================================================================
